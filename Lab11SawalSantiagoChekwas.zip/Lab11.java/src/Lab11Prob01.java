
/**
* File: Lab11Prob01
* Class: CSCI 1302
* Author: Arham Sawal, KK Chekwas, Anthony Santiago
* Created on: Nov 14, 2025
* Last Modified: Nov 14, 2025
* Description: Copy people.dat
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public class Lab11Prob01 {
	public static void main(String[] args) {
		File inputFile = new File("src/people.dat");
		File outputFile = new File("src/people-copy.dat");

		try (DataInputStream dis = new DataInputStream(new FileInputStream(inputFile));
				DataOutputStream dos = new DataOutputStream(new FileOutputStream(outputFile));) {
			while (true) {
				try {
					int age = dis.readInt();
					String name = dis.readUTF();
					String address = dis.readUTF();
					int zip = dis.readInt();
					double salary = dis.readDouble();

					System.out.printf("%d %s %s %d %.2f\n", age, name, address, zip, salary);

					dos.writeInt(age);
					dos.writeUTF(name);
					dos.writeUTF(address);
					dos.writeInt(zip);
					dos.writeDouble(salary);

				} catch (EOFException eof) {
					
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

