
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

public class Lab11Prob03 {

	public static void main(String[] args) {

		File inputFile = new File("src/people.dat");
		File objectOutputFile = new File("src/people-salary-sorted-objects.dat");

		ArrayList<Person> people = new ArrayList<>();

		try (DataInputStream dis = new DataInputStream(new FileInputStream(inputFile))) {

			while (true) {
				try {
					int age = dis.readInt();
					String name = dis.readUTF();
					String address = dis.readUTF();
					int zip = dis.readInt();
					double salary = dis.readDouble();

					Person p = new Person(age, name, address, zip, salary);
					people.add(p);

				} catch (EOFException eof) {
					break;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		Collections.sort(people);

		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(objectOutputFile))) {

			for (Person p : people) {
				oos.writeObject(p);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("people-salary-sorted-objects.dat written successfully.");
	}
}
