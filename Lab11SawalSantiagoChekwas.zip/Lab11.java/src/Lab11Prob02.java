
/**
* File: Lab11Prob01
* Class: CSCI 1302
* Author: Arham Sawal, KK Chekwas, Anthony Santiago
* Created on: Nov 14, 2025
* Last Modified: Nov 14, 2025
* Description: sort people salary
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Lab11Prob02 {
	public static void main(String[] args) {

		File inputFile = new File("src/people.dat");
		File outputFile = new File("src/people-salary-sorted.dat");

		ArrayList<Person> people = new ArrayList<>();

		try (DataInputStream dis = new DataInputStream(new FileInputStream(inputFile))) {

			while (true) {
				try {
					int age = dis.readInt();
					String name = dis.readUTF();
					String address = dis.readUTF();
					int zip = dis.readInt();
					double salary = dis.readDouble();

					Person p = new Person(age, name, address, zip, salary);

					people.add(p);

				} catch (EOFException eof) {
					break;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		Collections.sort(people);

		try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(outputFile))) {

			for (Person p : people) {
				dos.writeUTF(p.toString()); 
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("people-salary-sorted.dat written successfully.");
	}
}
